create definer = root@localhost view tworklinkuser as
select `pruereadroom`.`togetherwork`.`ID`              AS `ID`,
       `pruereadroom`.`togetherwork`.`togetherId`      AS `togetherId`,
       `pruereadroom`.`togetherwork`.`UID`             AS `UID`,
       `pruereadroom`.`togetherwork`.`togetherContent` AS `togetherContent`,
       `pruereadroom`.`togetherwork`.`togetherMap`     AS `togetherMap`,
       `pruereadroom`.`togetherwork`.`tCode`           AS `tCode`,
       `pruereadroom`.`user`.`username`                AS `username`,
       `pruereadroom`.`user`.`headpicture`             AS `headpicture`
from (`pruereadroom`.`togetherwork`
         join `pruereadroom`.`user` on ((`pruereadroom`.`togetherwork`.`UID` = `pruereadroom`.`user`.`UID`)));

