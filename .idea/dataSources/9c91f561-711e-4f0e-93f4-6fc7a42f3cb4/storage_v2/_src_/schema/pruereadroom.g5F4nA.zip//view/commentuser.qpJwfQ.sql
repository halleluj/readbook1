create view commentuser as
select `pruereadroom`.`comment`.`UID`         AS `UID`,
       `pruereadroom`.`comment`.`togetherId`  AS `togetherId`,
       `pruereadroom`.`comment`.`article_id`  AS `article_id`,
       `pruereadroom`.`comment`.`commentId`   AS `commentId`,
       `pruereadroom`.`comment`.`commentNote` AS `commentNote`,
       `pruereadroom`.`user`.`username`       AS `username`,
       `pruereadroom`.`user`.`headpicture`    AS `headpicture`
from (`pruereadroom`.`comment`
         join `pruereadroom`.`user` on ((`pruereadroom`.`comment`.`UID` = `pruereadroom`.`user`.`UID`)));

