create definer = root@localhost view applicationform as
select `pruereadroom`.`apply`.`ApplyID`        AS `ApplyID`,
       `pruereadroom`.`apply`.`UID`            AS `UID`,
       `pruereadroom`.`apply`.`activeID`       AS `activeID`,
       `pruereadroom`.`apply`.`w_id`           AS `w_id`,
       `pruereadroom`.`active`.`activeName`    AS `activeName`,
       `pruereadroom`.`active`.`activePicture` AS `activePicture`,
       `pruereadroom`.`active`.`activeNote`    AS `activeNote`,
       `pruereadroom`.`active`.`activeNumber`  AS `activeNumber`,
       `pruereadroom`.`active`.`activeCode`    AS `activeCode`
from (`pruereadroom`.`apply`
         join `pruereadroom`.`active` on ((`pruereadroom`.`apply`.`activeID` = `pruereadroom`.`active`.`activeID`)));

